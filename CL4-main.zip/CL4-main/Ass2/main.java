public static void main(String args[]) throws Exception 
{ 
int exitCode = ToolRunner.run(new WCDriver(), args); 
System.out.println(exitCode); 
} 
} 